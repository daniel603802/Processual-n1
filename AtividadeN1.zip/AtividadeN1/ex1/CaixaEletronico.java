import java.util.Scanner;

public class CaixaEletronico {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Valor do saque: ");
        int valor = sc.nextInt();
        int[] notas = {200, 100, 50, 20, 10, 5, 2};

        System.out.println("Notas:");
        for (int nota : notas) {
            int qtd = valor / nota;
            if (qtd > 0) {
                System.out.println(qtd + " x R$ " + nota);
            }
            valor = valor % nota;
        }
    }
}
