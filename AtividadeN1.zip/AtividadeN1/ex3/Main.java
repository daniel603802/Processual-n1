public class Main {
    public static void main(String[] args) {
        Funcionario[] f = {
            new Funcionario("Ana", "Analista", 4000),
            new Funcionario("Bruno", "Designer", 3500),
            new Funcionario("Carla", "Gerente", 8000),
            new Funcionario("Diego", "Estagiário", 1800),
            new Funcionario("Elisa", "Desenvolvedora", 5200)
        };
        double[] aumentos = {5, 10, 3, 15, 7};

        for (int i = 0; i < f.length; i++) {
            f[i].aumentarSalario(aumentos[i]);
            f[i].exibirDados();
        }
    }
}
