public class Funcionario {
    private String nome;
    private String cargo;
    private double salario;

    public Funcionario(String nome, String cargo, double salario) {
        this.nome = nome;
        this.cargo = cargo;
        this.salario = salario;
    }

    public void aumentarSalario(double percentual) {
        salario += salario * percentual / 100;
    }

    public double calcularSalarioAnual() {
        return salario * 12;
    }

    public void exibirDados() {
        System.out.printf("%s | %s | Salário: R$ %.2f | Anual: R$ %.2f%n",
                nome, cargo, salario, calcularSalarioAnual());
    }
}
