public class Main {
    public static void main(String[] args) {
        Funcionario[] funcionarios = {
            new Funcionario("Paulo", 3000),
            new Gerente("Marta", 8000),
            new Vendedor("Lucas", 2500, 20000)
        };

        for (Funcionario f : funcionarios) {
            System.out.printf("%s: R$ %.2f%n", f.getNome(), f.calcularSalario());
        }
    }
}
