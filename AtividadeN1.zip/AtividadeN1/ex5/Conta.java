public class Conta {
    protected int numero;
    protected String titular;
    protected double saldo;

    public Conta(int numero, String titular, double saldo) {
        this.numero = numero;
        this.titular = titular;
        this.saldo = saldo;
    }

    public void depositar(double valor) {
        saldo += valor;
    }

    public void sacar(double valor) {
        saldo -= valor;
    }

    public double calcularSaldo() {
        return saldo;
    }

    public void exibirDados() {
        System.out.printf("Conta %d | Titular: %s | Saldo: R$ %.2f%n",
                numero, titular, calcularSaldo());
    }
}
