public class ContaPoupanca extends Conta {
    private double rendimento; // ex.: 0.005 = 0,5%

    public ContaPoupanca(int numero, String titular, double saldo, double rendimento) {
        super(numero, titular, saldo);
        this.rendimento = rendimento;
    }

    @Override
    public double calcularSaldo() {
        return saldo * (1 + rendimento);
    }
}
