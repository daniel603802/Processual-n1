public class Main {
    public static void main(String[] args) {
        Conta[] contas = {
            new ContaCorrente(1, "Ana", 1000, 15),
            new ContaCorrente(2, "Bruno", 500, 15),
            new ContaPoupanca(3, "Carla", 2000, 0.005),
            new ContaPoupanca(4, "Diego", 800, 0.005)
        };

        contas[0].depositar(200);
        contas[1].sacar(100);
        contas[2].depositar(500);
        contas[3].sacar(50);

        for (Conta c : contas) {
            c.exibirDados();
        }
    }
}
