import java.util.Scanner;

public class SistemaVendas {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Quantidade de vendas: ");
        int n = sc.nextInt();

        double total = 0, maior = 0, menor = 0;
        int acima500 = 0;

        for (int i = 1; i <= n; i++) {
            System.out.print("Valor da venda " + i + ": ");
            double v = sc.nextDouble();
            total += v;
            if (i == 1 || v > maior) maior = v;
            if (i == 1 || v < menor) menor = v;
            if (v > 500) acima500++;
        }

        double taxa;
        if (total <= 1000) taxa = 0.03;
        else if (total <= 5000) taxa = 0.05;
        else taxa = 0.08;

        System.out.println("\n===== RESULTADO =====");
        System.out.printf("Total vendido: R$ %.2f%n", total);
        System.out.printf("Maior venda:   R$ %.2f%n", maior);
        System.out.printf("Menor venda:   R$ %.2f%n", menor);
        System.out.printf("Média:         R$ %.2f%n", total / n);
        System.out.println("Vendas acima de R$ 500,00: " + acima500);
        System.out.printf("Comissão (%.0f%%): R$ %.2f%n", taxa * 100, total * taxa);
    }
}
